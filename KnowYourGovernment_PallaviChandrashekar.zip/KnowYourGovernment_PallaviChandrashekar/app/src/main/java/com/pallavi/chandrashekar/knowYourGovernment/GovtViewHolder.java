package com.pallavi.chandrashekar.knowYourGovernment;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import com.pallavi.chandrashekar.knowYourGovernment.R;


public class GovtViewHolder extends RecyclerView.ViewHolder {
    public TextView officeNameView;
    public TextView officialNameView;
    public GovtViewHolder(View view) {
        super(view);
        officeNameView = (TextView) itemView.findViewById(R.id.officeNameTxtvw);
        officialNameView = (TextView) itemView.findViewById(R.id.officailNameTxtVw);
    }
}
