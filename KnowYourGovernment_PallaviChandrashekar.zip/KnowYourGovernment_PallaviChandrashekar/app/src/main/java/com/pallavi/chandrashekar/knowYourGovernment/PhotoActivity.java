package com.pallavi.chandrashekar.knowYourGovernment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;


public class PhotoActivity extends AppCompatActivity {
    TextView about;
    TextView aboutName;
    ImageView imageView;
    ConstraintLayout constraintLayout;
    GovernmentDetails government;
    TextView locTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photo_activity);


        about = (TextView) findViewById(R.id.aboutTv);
        aboutName= (TextView) findViewById(R.id.nameOfThePerson);
        imageView = (ImageView) findViewById(R.id.imageView);
        constraintLayout = (ConstraintLayout) findViewById(R.id.constraint);
        locTv = (TextView) findViewById(R.id.locTv);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        Intent ofcActIntent = getIntent();
        government = (GovernmentDetails) ofcActIntent.getSerializableExtra(getString(R.string.SerializeGovernmentObject));
        AddressInfo localAddress = government.getLocalAddress();
        about.setText(getAboutOfficialString(government));
        aboutName.setText(getAboutString(government));
        locTv.setText(localAddress.getCity()+","+ localAddress.getState()+","+ localAddress.getZip());
        loadImage(government);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent noteIntent = new Intent();
                setResult(RESULT_OK, noteIntent);
                NavUtils.navigateUpFromSameTask(this);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /*@Override
    public void onBackPressed(){
        Intent clickedNoteIntent = new Intent();
        setResult(RESULT_OK, clickedNoteIntent);
        finish();
    }*/

    public String getAboutOfficialString(GovernmentDetails government){
        String aboutString = "";
        aboutString = government.getOfficeName()
                + "\n"+government.getOfficial().getName();
        if(government.getOfficial().getPartyName()!=null && government.getOfficial().getPartyName().length() > 0)
        {
            aboutString =aboutString + "\n("+government.getOfficial().getPartyName()+")";
            if(government.getOfficial().getPartyName().equals(OfficialActivity.PartyConstant.DEMOCRATIC))
            {
                int myColor = getResources().getColor(R.color.blue);
                constraintLayout.setBackgroundColor(myColor);
            }
            else if (government.getOfficial().getPartyName().equals(OfficialActivity.PartyConstant.REPUBLICAN))
            {
                int myColor = getResources().getColor(R.color.red);
                constraintLayout.setBackgroundColor(myColor);
            }
            else
            {
                int myColor = getResources().getColor(R.color.black);
                constraintLayout.setBackgroundColor(myColor);
            }
        }

        return government.getOfficeName();
    }
    public String getAboutString(GovernmentDetails government){
        String aboutString = "";
        aboutString = government.getOfficeName()
                + "\n"+government.getOfficial().getName();
        if(government.getOfficial().getPartyName()!=null && government.getOfficial().getPartyName().length() > 0)
        {
            aboutString =aboutString + "\n("+government.getOfficial().getPartyName()+")";
            if(government.getOfficial().getPartyName().equals(OfficialActivity.PartyConstant.DEMOCRATIC))
            {
                int myColor = getResources().getColor(R.color.blue);
                constraintLayout.setBackgroundColor(myColor);
            }
            else if (government.getOfficial().getPartyName().equals(OfficialActivity.PartyConstant.REPUBLICAN))
            {
                int myColor = getResources().getColor(R.color.red);
                constraintLayout.setBackgroundColor(myColor);
            }
            else
            {
                int myColor = getResources().getColor(R.color.black);
                constraintLayout.setBackgroundColor(myColor);
            }
        }



        return government.getOfficial().getName();
    }
    private void loadImage(final GovernmentDetails goverment){
        final String photoUrl = goverment.getOfficial().getPhotoUrl();
        if ( photoUrl != null) {
            Picasso picasso = new Picasso.Builder(this).listener(new Picasso.Listener() {
                @Override
                public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                    final String changedUrl = photoUrl.replace("http:", "https:");
                    picasso.load(changedUrl)
                            .fit()
                            .error(R.drawable.brokenimage)
                            .placeholder(R.drawable.placeholder)
                            .into(imageView);
                }
            }).build();

            picasso.load(photoUrl)
                    .fit()
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.placeholder)
                    .into(imageView);

        } else {
            Picasso.with(this).load(photoUrl)
                    .fit()
                    .centerCrop()
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.missingimage)
                    .into(imageView);
        }
    }
}
