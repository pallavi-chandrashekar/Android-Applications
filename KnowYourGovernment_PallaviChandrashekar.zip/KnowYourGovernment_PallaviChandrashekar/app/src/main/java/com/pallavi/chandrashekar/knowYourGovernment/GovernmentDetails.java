package com.pallavi.chandrashekar.knowYourGovernment;

import java.io.Serializable;


public class GovernmentDetails implements Serializable{
    private String officeName;
    private int officeIndex;
    private PersonalDetails official;
    AddressInfo localAddress;

    public GovernmentDetails(String officeName, int officeIndex, PersonalDetails official) {
        this.officeName = officeName;
        this.officeIndex = officeIndex;
        this.official = official;
    }

    public String getOfficeName() {
        return officeName;
    }

    public void setOfficeName(String officeName) {
        this.officeName = officeName;
    }

    public int getOfficeIndex() {
        return officeIndex;
    }

    public void setOfficeIndex(int officeIndex) {
        this.officeIndex = officeIndex;
    }

    public PersonalDetails getOfficial() {
        return official;
    }

    public void setOfficial(PersonalDetails official) {
        this.official = official;
    }

    public AddressInfo getLocalAddress() {
        return localAddress;
    }

    public void setLocalAddress(AddressInfo localAddress) {
        this.localAddress = localAddress;
    }

}
