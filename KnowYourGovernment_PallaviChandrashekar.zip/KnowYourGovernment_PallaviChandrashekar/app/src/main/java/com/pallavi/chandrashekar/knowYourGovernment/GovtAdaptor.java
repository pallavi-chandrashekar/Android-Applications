package com.pallavi.chandrashekar.knowYourGovernment;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;


public class GovtAdaptor extends RecyclerView.Adapter<GovtViewHolder> {
    MainActivity mainActivity;
    List<GovernmentDetails> governmentList;

    public GovtAdaptor(MainActivity mainActivity, List<GovernmentDetails> governmentList) {
        this.mainActivity =  mainActivity;
        this.governmentList = governmentList;
    }

    @Override
    public GovtViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View thisItemsView = LayoutInflater.from(parent.getContext()).inflate(R.layout.official_list,
                parent, false);
        thisItemsView.setOnClickListener(mainActivity);
        return new GovtViewHolder(thisItemsView);
    }

    @Override
    public void onBindViewHolder(GovtViewHolder holder, int position) {
        GovernmentDetails ourGovernment = governmentList.get(position);
        holder.officeNameView.setText(ourGovernment.getOfficeName());
        if(ourGovernment.getOfficial().getPartyName()==null) {
            holder.officialNameView.setText(ourGovernment.getOfficial().getName());

        }
        else {
            //holder.officialNameView.setText(ourGovernment.getOfficial().getName());
            holder.officialNameView.setText(ourGovernment.getOfficial().getName()+" ("+ ourGovernment.getOfficial().getPartyName()+")");
        }


    }

    @Override
    public int getItemCount() {
        return governmentList.size();
    }
}
