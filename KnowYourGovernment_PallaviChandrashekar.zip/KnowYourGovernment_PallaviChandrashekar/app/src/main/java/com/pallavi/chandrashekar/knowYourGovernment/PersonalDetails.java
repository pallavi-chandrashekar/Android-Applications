package com.pallavi.chandrashekar.knowYourGovernment;

import java.io.Serializable;
import java.util.List;


public class PersonalDetails implements Serializable{
    private String name;
    private AddressInfo address;
    private String partyName;
    private List<String> phoneNumbers;
    private List<String> emailIds;
    private List<String> urls;
    private String photoUrl;
    private SocialMediaChannel channel;

    public PersonalDetails(String name, AddressInfo address, String partyName, List<String> phoneNumbers, List<String> emailIds, List<String> urls, String photoUrl, SocialMediaChannel channel) {
        this.name = name;
        this.address = address;
        this.partyName = partyName;
        this.phoneNumbers = phoneNumbers;
        this.emailIds = emailIds;
        this.urls = urls;
        this.photoUrl = photoUrl;
        this.channel = channel;
    }

    public List<String> getEmailIds() {
        return emailIds;
    }

    public void setEmailIds(List<String> emailIds) {
        this.emailIds = emailIds;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public AddressInfo getAddress() {
        return address;
    }

    public void setAddress(AddressInfo address) {
        this.address = address;
    }

    public String getPartyName() {
        return partyName;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }

    public List<String> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<String> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public List<String> getUrls() {
        return urls;
    }

    public void setUrls(List<String> urls) {
        this.urls = urls;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public SocialMediaChannel getChannel() {
        return channel;
    }

    public void setChannel(SocialMediaChannel channel) {
        this.channel = channel;
    }

}
