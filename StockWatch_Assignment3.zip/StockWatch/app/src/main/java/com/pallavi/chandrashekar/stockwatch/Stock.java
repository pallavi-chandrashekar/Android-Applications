package com.pallavi.chandrashekar.stockwatch;

public class Stock {

    private String symbol;
    private String name;
    private double price;
    private double priceChange;
    private double percentChange;

    public Stock(String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getPriceChange() {
        return priceChange;
    }

    public double getPercentChange() {
        return percentChange;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setPriceChange(double priceChange) {
        this.priceChange = priceChange;
    }

    public void setPercentChange(double percentChange) {
        this.percentChange = percentChange;
    }
}
