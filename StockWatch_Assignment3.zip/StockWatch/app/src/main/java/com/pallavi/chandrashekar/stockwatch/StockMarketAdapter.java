package com.pallavi.chandrashekar.stockwatch;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class StockMarketAdapter extends RecyclerView.Adapter<StockMarketHolder> {

    private List<Stock> stocks;
    private MainActivity mainActivity;

    @Override
    public StockMarketHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listofstock, parent, false);
        view.setOnLongClickListener(mainActivity);
        view.setOnClickListener(mainActivity);
        return new StockMarketHolder(view);
    }

    public StockMarketAdapter(MainActivity mainActivity, List<Stock> stocks) {
        this.mainActivity = mainActivity;
        this.stocks = stocks;
    }

    @Override
    public void onBindViewHolder(StockMarketHolder stockMarketHolder, int position) {
        Stock stock = stocks.get(position);
        stockMarketHolder.stockName.setText(stock.getName());
        stockMarketHolder.stockPrice.setText(String.valueOf(stock.getPrice()));
        stockMarketHolder.stockSymbol.setText(stock.getSymbol());
        if (stock.getPriceChange() > 0)
        {
            stockMarketHolder.change.setText("▲ "+String.valueOf(stock.getPriceChange())+"("+String.valueOf(stock.getPercentChange()).substring(0,5)+"%)");
            stockMarketHolder.stockName.setTextColor(Color.GREEN);
            stockMarketHolder.stockPrice.setTextColor(Color.GREEN);
            stockMarketHolder.stockSymbol.setTextColor(Color.GREEN);
            stockMarketHolder.change.setTextColor(Color.GREEN);
        }else{
            stockMarketHolder.change.setText("▼ "+String.valueOf(stock.getPriceChange())+"("+String.valueOf(stock.getPercentChange()).substring(0,5)+"%)");
            stockMarketHolder.stockName.setTextColor(Color.RED);
            stockMarketHolder.stockPrice.setTextColor(Color.RED);
            stockMarketHolder.stockSymbol.setTextColor(Color.RED);
            stockMarketHolder.change.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }
}
