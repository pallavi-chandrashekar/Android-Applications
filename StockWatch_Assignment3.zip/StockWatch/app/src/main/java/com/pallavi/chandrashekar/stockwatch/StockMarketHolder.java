package com.pallavi.chandrashekar.stockwatch;


import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import com.pallavi.chandrashekar.stockwatch.R;

public class StockMarketHolder extends RecyclerView.ViewHolder {
    public TextView stockName;
    public TextView stockSymbol;
    public TextView stockPrice;
    public TextView change;

    public StockMarketHolder(View itemView) {
        super(itemView);
        stockName = (TextView) itemView.findViewById(R.id.name);
        stockSymbol = (TextView) itemView.findViewById(R.id.symbol);
        change = (TextView) itemView.findViewById(R.id.change);
        stockPrice = (TextView) itemView.findViewById(R.id.price);
    }
}
