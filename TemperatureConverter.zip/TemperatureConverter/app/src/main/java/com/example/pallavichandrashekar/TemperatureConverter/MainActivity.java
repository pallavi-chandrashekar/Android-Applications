package com.example.pallavichandrashekar.TemperatureConverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioButton f2c,c2f;
    EditText enteredTemperature,resultInTemperature;
    TextView displayTemperature;
    private String resultTemperature = " ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enteredTemperature = (EditText) findViewById(R.id.temperatureValue); // linking temperature vale to a variable.
        f2c = findViewById(R.id.f2c); // linking the radio button using id to a variable.
        c2f = findViewById(R.id.c2f); // linking the radio button using id to a variable.
        resultInTemperature = findViewById(R.id.result);
        displayTemperature = findViewById(R.id.displayResults);

    }

    @Override
    protected void onSaveInstanceState(Bundle savedState)
    {
        super.onSaveInstanceState(savedState);
        savedState.putString("value",resultTemperature);

    }
    public void temperatureConversion(View view)
    {

        String temp= enteredTemperature.getText().toString();
        double tempValue = new Double(temp);
        double result=0.0;
        String appendText = null;

        if(f2c.isChecked()) {

            result = conversion.fahrenheitTocelsius(tempValue);
            appendText="Fahrenheit "+tempValue +" to Celsius ";
        }

        else {
            result = conversion.celsiusTofahrenheit(tempValue);
            appendText="Celsius "+tempValue+ " to Fahrenheit ";
        }

        resultTemperature = ""+String.format("%.1f", result);
        resultInTemperature.setText(resultTemperature);
        displayTemperature.append(appendText + resultTemperature+"\n");
        displayTemperature.setMovementMethod(new ScrollingMovementMethod());

    }

    @Override
    protected void onRestoreInstanceState(Bundle state)
    {
        displayTemperature.append(state.getString("value"));
        super.onRestoreInstanceState(state);

    }

}
