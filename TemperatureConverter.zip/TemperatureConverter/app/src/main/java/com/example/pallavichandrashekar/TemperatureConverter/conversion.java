package com.example.pallavichandrashekar.TemperatureConverter;

import android.widget.EditText;

public class conversion {

    static double solution;
    public static double fahrenheitTocelsius(double temp){

        solution = (temp - 32.0) / 1.8;
    return solution;

    }

    public static double celsiusTofahrenheit(double temp)
    {
        solution= (temp * 1.8) + 32;
        return solution;
    }

}
